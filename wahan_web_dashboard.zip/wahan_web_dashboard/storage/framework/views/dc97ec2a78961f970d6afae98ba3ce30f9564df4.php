<?php $__env->startSection('content'); ?>



    
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal--fir">
        Add New Driver
    </button>

    
    <div class="card card-body mt-4 table-responsive">
        <div class="title font-weight-bold">
            Vehicle Lists
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($drivers)): ?>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td>
                                <?php echo e($item->id); ?>

                            </td>
                            <td>
                                <img src="/images/driver/<?php echo e($item->image); ?>" class="img-fluid" width="90px" alt="">
                            </td>
                            <td>
                                <?php echo e($item->name); ?>

                            </td>
                            <td>
                                <?php echo e($item->phone); ?>

                            </td>
                            <td>
                                <?php echo e($item->email); ?>

                            </td>
                            <td>
                                <?php echo e($item->address); ?>

                            </td>
                            <td>
                                <div class="d-flex">
                                    

                                     <a  href="/driverinfo/delete/<?php echo e($item->id); ?>"  class="btn btn-sm btn-danger mr-2" data-toggle="tooltip"  ">
                                        <i class="material-icons">delete</i>
                                    </a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>
    
    <div class="modal fade" id="modal--fir" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Driver</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/driverinfo/add" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Image *</label>
                            <input name="image" type="file" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Full Name *</label>
                            <input name="name" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">phone *</label>
                            <input name="phone" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">email *</label>
                            <input name="email" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">address *</label>
                            <input name="address" type="text" class="form-control" required>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger error-container mt-2">
                                <div class="alert alert-danger">
                                    <ul class="errors">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>

                        <button type="submit" class="btn btn-success">Add</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\Desktop\wahan_web_app\resources\views/driverinfo/home.blade.php ENDPATH**/ ?>