<?php $__env->startSection('content'); ?>



    
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal--fir">
        Add New Vehicle
    </button>

    
    <div class="card card-body mt-4 table-responsive">
        <div class="title font-weight-bold">
            Vehicle Lists
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Color</th>
                    <th>Seat</th>
                    <th>Platenumber</th>
                    <th>Fueltype</th>
                    <th>Driver</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($vehicles)): ?>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td>
                                <?php echo e($item->id); ?>

                            </td>
                            <td>
                                <img src="/images/vehicles/<?php echo e($item->image); ?>" class="img-fluid" width="90px" alt="">
                            </td>
                            <td>
                                <?php echo e($item->name); ?>

                            </td>
                            <td>
                                <?php echo e($item->color); ?>

                            </td>
                            <td>
                                <?php echo e($item->seat); ?>

                            </td>
                            <td>
                                <?php echo e($item->platenumber); ?>

                            </td>
                            <td>
                                <?php echo e($item->fueltype); ?>

                            </td>
                            <td>
                                <?php if(!empty($item->driver)): ?>
                                    <span>
                                        <?php echo e($item->driver->name); ?>

                                    </span>
                                    <span class="ml-2">
                                        <button type="button" class="btn btn-sm btn-dark btn-float" data-toggle="modal"
                                            data-target="#modal-edit-driver-<?php echo e($item->id); ?>" data-toggle="tooltip"
                                            title="Send Notice ">
                                            <i class="material-icons">edit</i>
                                        </button>

                                    </span>
                                <?php else: ?>
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-sm btn-info btn-float" data-toggle="modal"
                                            data-target="#modal-add-driver-<?php echo e($item->id); ?>" data-toggle="tooltip"
                                            title="Send Notice ">
                                            <i class="material-icons">add</i>
                                        </button>
                                    </div>
                                <?php endif; ?>

                            </td>
                            <td>
                                <div class="d-flex">

                                    <button type="button" class="btn btn-sm btn-dark" data-toggle="modal"
                                        data-target="#modal-<?php echo e($item->id); ?>" data-toggle="tooltip"
                                        title="Send Notice ">
                                        <i class="material-icons">edit</i>
                                    </button>
                                    <a href="/vehicles/delete/<?php echo e($item->id); ?>" class="btn btn-sm btn-danger mr-2"
                                        data-toggle="tooltip">
                                        <i class=" material-icons">delete</i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>
    
    <div class="modal fade" id="modal--fir" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Vehicle</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/vehicles/add" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Image *</label>
                            <input name="image" type="file" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Full Name *</label>
                            <input name="name" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Color *</label>
                            <input name="color" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Seat *</label>
                            <input name="seat" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Platenumber *</label>
                            <input name="platenumber" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Fueltype *</label>
                            <input name="fueltype" type="text" class="form-control" required>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger error-container mt-2">
                                <div class="alert alert-danger">
                                    <ul class="errors">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>

                        <button type="submit" class="btn btn-success">Add</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>




    <?php if(!empty($vehicles)): ?>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="modal fade" id="modal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Vehicle</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/update" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input name="id" type="hidden" class="form-control" value="<?php echo e($item->id); ?>" required>
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Full Name *</label>
                                    <input name="name" type="text" class="form-control" value="<?php echo e($item->name); ?>"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Color *</label>
                                    <input name="color" type="text" class="form-control" value="<?php echo e($item->color); ?>"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Seat *</label>
                                    <input name="seat" type="text" class="form-control" value="<?php echo e($item->seat); ?>"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Platenumber *</label>
                                    <input name="platenumber" type="text" class="form-control"
                                        value="<?php echo e($item->platenumber); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Fueltype *</label>
                                    <input name="fueltype" type="text" class="form-control" value="<?php echo e($item->fueltype); ?>"
                                        required>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-success">Update</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="modal-add-driver-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Driver For "<?php echo e($item->name); ?>"</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/adddriver" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input name="id" type="hidden" class="form-control" value="<?php echo e($item->id); ?>" required>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Driver *</label>
                                    <select required name="driver_id" class="form-control">
                                        <?php if(!empty($drivers)): ?>
                                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-success">Add</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
            
            <div class="modal fade" id="modal-edit-driver-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Driver For "<?php echo e($item->name); ?>"</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/adddriver" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input name="id" type="hidden" class="form-control" value="<?php echo e($item->id); ?>" required>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Driver *</label>
                                    <select required name="driver_id" class="form-control">
                                        <?php if(!empty($drivers)): ?>
                                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($item->driver) && $item->driver->id == $driver->id): ?>
                                                    <option value="<?php echo e($driver->id); ?>" selected><?php echo e($driver->name); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->name); ?></option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-success">Add</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WINNEE\Islinton\wahan\wahan_web_app\resources\views/vehicles/home.blade.php ENDPATH**/ ?>