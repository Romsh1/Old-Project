<?php $__env->startSection('content'); ?>


    <div class="absent-trainer">
        
        <div class="card card-body mt-4 table-responsive">
            <div class="h3 title font-weight-bold">
                Customer Info 
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Created at</th>
                        <th>Fullname</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($users)): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->email != 'admin@admin.com'): ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->created_at); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->fullname); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->phone); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->address); ?>

                                    </td>
                                    
                                </tr>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WINNEE\Islinton\wahan\wahan_web_app\resources\views/customerinfo/home.blade.php ENDPATH**/ ?>