<?php $__env->startSection('content'); ?>



    <div class="absent-trainer">
        
        <div class="card card-body mt-4 table-responsive">
            <div class="h3 title font-weight-bold">
                Booking Requests
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Booked On</th>
                        <th>Booked BY</th>
                        <th>Vehicle</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Departure</th>
                        <th>Return</th>
                        <th>No of passenger</th>
                        <th>Notice</th>
                        <th>Confirmed/Accepted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($bookings)): ?>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    #<?php echo e($item->id); ?>

                                </td>
                                <td>
                                    <?php echo e($item->created_at); ?>

                                </td>
                                <td>
                                    <a href="/customerinfo">
                                        <?php echo e($item->user->fullname); ?>

                                    </a>

                                </td>
                                <td>
                                    <?php if(!empty($item->vehicle)): ?>

                                        <a href="/vehicles">
                                            <?php echo e($item->vehicle->name); ?>

                                        </a>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php echo e($item->from); ?>

                                </td>
                                <td>
                                    <?php echo e($item->to); ?>

                                </td>
                                <td>
                                    <?php echo e($item->departure); ?>

                                </td>
                                <td>
                                    <?php echo e($item->return); ?>

                                </td>
                                <td>
                                    <?php echo e($item->noofpassengers); ?>

                                </td>
                                <td>
                                    <?php echo e($item->message); ?>

                                </td>
                                <td>
                                    <?php if($item->isBookingConfirmed): ?>

                                        <a href="#" class="badge badge-success px-2 py-1 badge-pill ">Accepted</a>
                                    <?php else: ?>
                                        <a href="#" class="badge badge-danger px-2 py-1 badge-pill ">Not Accepted</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <a href="/bookingrequest/<?php echo e($item->id); ?>/accept"
                                            class="btn btn-sm btn-float btn-success mr-2" data-toggle="tooltip"
                                            title="Confirmed/Accept Booking">
                                            <i class="material-icons">check</i>
                                        </a>
                                        <a href="/bookingrequest/<?php echo e($item->id); ?>/decline"
                                            class="btn btn-sm btn-float btn-danger mr-2" data-toggle="tooltip"
                                            title="Decline">
                                            <i class="material-icons">close</i>
                                        </a>
                                        <button type="button" class="btn btn-info btn-sm btn-float" data-toggle="modal"
                                            data-target="#modalsendnotice-<?php echo e($item->id); ?>">
                                            <i class="material-icons">chat</i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>




    <?php if(!empty($bookings)): ?>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="modal fade" id="modalsendnotice-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Send Notice</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/bookingrequest/<?php echo e($item->id); ?>/message" method="POST">
                                <?php echo csrf_field(); ?>
                                <input name="user_id" type="hidden" class="form-control" value="<?php echo e($item->user_id); ?>"
                                    required>

                                <div class="form-group">
                                    <label>Notice *</label>
                                    <textarea name="notice" class="form-control"></textarea>
                                </div>

                                <button type="submit" class="btn btn-success">Send</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\Desktop\wahan_web_app\resources\views/bookingrequest/home.blade.php ENDPATH**/ ?>