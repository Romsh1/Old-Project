<?php $__env->startSection('content'); ?>



    <div class="absent-trainer">
        
        <div class="card card-body mt-4 table-responsive">
            <div class="h3 title font-weight-bold">
                Booking Requests
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Booked BY</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Departure</th>
                        <th>Return</th>
                        <th>No of passenger</th>
                        <th>Time</th>
                        <th>Vehicle</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($absent_trainers)): ?>
                        <?php $__currentLoopData = $absent_trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <?php echo e($item->id); ?>

                                </td>
                                <td>
                                    <?php echo e($item->fullname); ?>

                                </td>
                                <td>
                                    <?php echo e($item->phone); ?>

                                </td>
                                <td>
                                    <?php echo e($item->address); ?>

                                </td>
                                <td>
                                    <?php echo e($item->username); ?>

                                </td>
                                <td>
                                    <?php if($item->shift_m): ?>
                                        YES
                                    <?php else: ?>
                                        NO
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($item->shift_e): ?>
                                        YES
                                    <?php else: ?>
                                        NO
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <a href="/trainers/view/<?php echo e($item->id); ?>" class="btn btn-sm btn-success mr-2"
                                            data-toggle="tooltip" title="View Trainer">
                                            <i class="material-icons">visibility</i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WINNEE\Islinton\wahan\wahan_app\resources\views/bookingrequest/home.blade.php ENDPATH**/ ?>