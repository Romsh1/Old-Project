<?php $__env->startSection('content'); ?>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WINNEE\Islinton\wahan\wahan_app\resources\views/customerinfo/home.blade.php ENDPATH**/ ?>