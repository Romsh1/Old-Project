@extends('layout.base')
@section('content')



    <div class="absent-trainer">
        {{-- list --}}
        <div class="card card-body mt-4 table-responsive">
            <div class="h3 title font-weight-bold">
                Booking Requests
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Booked On</th>
                        <th>Booked BY</th>
                        <th>Vehicle</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Departure</th>
                        <th>Return</th>
                        <th>No of passenger</th>
                        <th>Notice</th>
                        <th>Confirmed/Accepted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @if (!empty($bookings))
                        @foreach ($bookings as $item)
                            <tr>

                                <td>
                                    #{{ $item->id }}
                                </td>
                                <td>
                                    {{ $item->created_at }}
                                </td>
                                <td>
                                    <a href="/customerinfo">
                                        {{ $item->user->fullname }}
                                    </a>

                                </td>
                                <td>
                                    @if (!empty($item->vehicle))

                                        <a href="/vehicles">
                                            {{ $item->vehicle->name }}
                                        </a>
                                    @endif
                                </td>

                                <td>
                                    {{ $item->from }}
                                </td>
                                <td>
                                    {{ $item->to }}
                                </td>
                                <td>
                                    {{ $item->departure }}
                                </td>
                                <td>
                                    {{ $item->return }}
                                </td>
                                <td>
                                    {{ $item->noofpassengers }}
                                </td>
                                <td>
                                    {{ $item->message }}
                                </td>
                                <td>
                                    @if ($item->isBookingConfirmed)

                                        <a href="#" class="badge badge-success px-2 py-1 badge-pill ">Accepted</a>
                                    @else
                                        <a href="#" class="badge badge-danger px-2 py-1 badge-pill ">Not Accepted</a>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <a href="/bookingrequest/{{ $item->id }}/accept"
                                            class="btn btn-sm btn-float btn-success mr-2" data-toggle="tooltip"
                                            title="Confirmed/Accept Booking">
                                            <i class="material-icons">check</i>
                                        </a>
                                        <a href="/bookingrequest/{{ $item->id }}/decline"
                                            class="btn btn-sm btn-float btn-danger mr-2" data-toggle="tooltip"
                                            title="Decline">
                                            <i class="material-icons">close</i>
                                        </a>
                                        <button type="button" class="btn btn-info btn-sm btn-float" data-toggle="modal"
                                            data-target="#modalsendnotice-{{ $item->id }}">
                                            <i class="material-icons">chat</i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        {{-- !ENDS list --}}
    </div>




@endsection

@section('modal')




    @if (!empty($bookings))
        @foreach ($bookings as $item)

            <div class="modal fade" id="modalsendnotice-{{ $item->id }}" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Send Notice</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/bookingrequest/{{ $item->id }}/message" method="POST">
                                @csrf
                                <input name="user_id" type="hidden" class="form-control" value="{{ $item->user_id }}"
                                    required>

                                <div class="form-group">
                                    <label>Notice *</label>
                                    <textarea name="notice" class="form-control"></textarea>
                                </div>

                                <button type="submit" class="btn btn-success">Send</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

        @endforeach
    @endif

@endsection
