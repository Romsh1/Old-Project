@extends('layout.base')
@section('content')



    {{-- add new member modal --}}
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal--fir">
        Add New Vehicle
    </button>

    {{-- list --}}
    <div class="card card-body mt-4 table-responsive">
        <div class="title font-weight-bold">
            Vehicle Lists
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Color</th>
                    <th>Seat</th>
                    <th>Platenumber</th>
                    <th>Fueltype</th>
                    <th>Driver</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @if (!empty($vehicles))
                    @foreach ($vehicles as $item)
                        <tr>

                            <td>
                                {{ $item->id }}
                            </td>
                            <td>
                                <img src="/images/vehicles/{{ $item->image }}" class="img-fluid" width="90px" alt="">
                            </td>
                            <td>
                                {{ $item->name }}
                            </td>
                            <td>
                                {{ $item->color }}
                            </td>
                            <td>
                                {{ $item->seat }}
                            </td>
                            <td>
                                {{ $item->platenumber }}
                            </td>
                            <td>
                                {{ $item->fueltype }}
                            </td>
                            <td>
                                @if (!empty($item->driver))
                                    <span>
                                        {{ $item->driver->name }}
                                    </span>
                                    <span class="ml-2">
                                        <button type="button" class="btn btn-sm btn-dark btn-float" data-toggle="modal"
                                            data-target="#modal-edit-driver-{{ $item->id }}" data-toggle="tooltip"
                                            title="Send Notice ">
                                            <i class="material-icons">edit</i>
                                        </button>

                                    </span>
                                @else
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-sm btn-info btn-float" data-toggle="modal"
                                            data-target="#modal-add-driver-{{ $item->id }}" data-toggle="tooltip"
                                            title="Send Notice ">
                                            <i class="material-icons">add</i>
                                        </button>
                                    </div>
                                @endif

                            </td>
                            <td>
                                <div class="d-flex">

                                    <button type="button" class="btn btn-sm btn-dark" data-toggle="modal"
                                        data-target="#modal-{{ $item->id }}" data-toggle="tooltip"
                                        title="Send Notice ">
                                        <i class="material-icons">edit</i>
                                    </button>
                                    <a href="/vehicles/delete/{{ $item->id }}" class="btn btn-sm btn-danger mr-2"
                                        data-toggle="tooltip">
                                        <i class=" material-icons">delete</i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>

@endsection



@section('modal')
    {{-- model to add new --}}
    <div class="modal fade" id="modal--fir" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Vehicle</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/vehicles/add" method="POST" enctype="multipart/form-data">
                        @csrf
                        {{-- <div class="form-group">
                        <label for="exampleInputEmail1">Image (optional)</label>
                        <input name="image" type="file" class="form-control">
                    </div> --}}
                        <div class="form-group">
                            <label for="exampleInputEmail1">Image *</label>
                            <input name="image" type="file" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Full Name *</label>
                            <input name="name" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Color *</label>
                            <input name="color" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Seat *</label>
                            <input name="seat" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Platenumber *</label>
                            <input name="platenumber" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Fueltype *</label>
                            <input name="fueltype" type="text" class="form-control" required>
                        </div>
                        @if ($errors->any())
                            <div class="alert alert-danger error-container mt-2">
                                <div class="alert alert-danger">
                                    <ul class="errors">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif

                        <button type="submit" class="btn btn-success">Add</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>




    @if (!empty($vehicles))
        @foreach ($vehicles as $item)
            {{-- //edit --}}
            <div class="modal fade" id="modal-{{ $item->id }}" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Vehicle</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/update" method="POST" enctype="multipart/form-data">
                                @csrf
                                <input name="id" type="hidden" class="form-control" value="{{ $item->id }}" required>
                                {{-- <div class="form-group">
                                    <label for="exampleInputEmail1">Image *</label>
                                    <input name="image" type="file" class="form-control" required>
                                </div> --}}
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Full Name *</label>
                                    <input name="name" type="text" class="form-control" value="{{ $item->name }}"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Color *</label>
                                    <input name="color" type="text" class="form-control" value="{{ $item->color }}"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Seat *</label>
                                    <input name="seat" type="text" class="form-control" value="{{ $item->seat }}"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Platenumber *</label>
                                    <input name="platenumber" type="text" class="form-control"
                                        value="{{ $item->platenumber }}" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Fueltype *</label>
                                    <input name="fueltype" type="text" class="form-control" value="{{ $item->fueltype }}"
                                        required>
                                </div>
                                @if ($errors->any())
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                @endif

                                <button type="submit" class="btn btn-success">Update</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            {{-- //add driver --}}
            <div class="modal fade" id="modal-add-driver-{{ $item->id }}" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Driver For "{{ $item->name }}"</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/adddriver" method="POST" enctype="multipart/form-data">
                                @csrf
                                <input name="id" type="hidden" class="form-control" value="{{ $item->id }}" required>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Driver *</label>
                                    <select required name="driver_id" class="form-control">
                                        @if (!empty($drivers))
                                            @foreach ($drivers as $driver)
                                                <option value="{{ $driver->id }}">{{ $driver->name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->any())
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                @endif

                                <button type="submit" class="btn btn-success">Add</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            {{-- //edit driver --}}
            {{-- //add driver --}}
            <div class="modal fade" id="modal-edit-driver-{{ $item->id }}" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Driver For "{{ $item->name }}"</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="/vehicles/adddriver" method="POST" enctype="multipart/form-data">
                                @csrf
                                <input name="id" type="hidden" class="form-control" value="{{ $item->id }}" required>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Driver *</label>
                                    <select required name="driver_id" class="form-control">
                                        @if (!empty($drivers))
                                            @foreach ($drivers as $driver)
                                                @if (!empty($item->driver) && $item->driver->id == $driver->id)
                                                    <option value="{{ $driver->id }}" selected>{{ $driver->name }}
                                                    </option>
                                                @else
                                                    <option value="{{ $driver->id }}">{{ $driver->name }}</option>
                                                @endif

                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->any())
                                    <div class="alert alert-danger error-container mt-2">
                                        <div class="alert alert-danger">
                                            <ul class="errors">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                @endif

                                <button type="submit" class="btn btn-success">Add</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>



        @endforeach
    @endif

@endsection
