@extends('layout.base')
@section('content')


    <div class="absent-trainer">
        {{-- list --}}
        <div class="card card-body mt-4 table-responsive">
            <div class="h3 title font-weight-bold">
                Customer Info 
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Created at</th>
                        <th>Fullname</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        {{-- <th>Action</th> --}}
                    </tr>
                </thead>
                <tbody>
                    @if (!empty($users))
                        @foreach ($users as $item)
                            @if ($item->email != 'admin@admin.com')
                                <tr>
                                    <td>
                                        {{ $item->id }}
                                    </td>
                                    <td>
                                        {{ $item->created_at }}
                                    </td>
                                    <td>
                                        {{ $item->fullname }}
                                    </td>
                                    <td>
                                        {{ $item->phone }}
                                    </td>
                                    <td>
                                        {{ $item->email }}
                                    </td>
                                    <td>
                                        {{ $item->address }}
                                    </td>
                                    {{-- <td>
                                        <div class="d-flex">
                                            <a href="/bookingrequest/delete/{{ $item->id }}"
                                                class="btn btn-sm btn-danger mr-2" data-toggle="tooltip"
                                                title="View Trainer">
                                                <i class="material-icons">delete</i>
                                            </a>
                                        </div>
                                    </td> --}}
                                </tr>
                            @endif

                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        {{-- !ENDS list --}}
    </div>




@endsection
