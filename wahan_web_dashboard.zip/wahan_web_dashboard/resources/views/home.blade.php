@extends('layout.base')
@section('content')

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </nav>



    <div class="container my-4">
        <div class="row justify-content-center">
            <div class="col-12 col-md-6 mt-2">
                    <a href="/bookingrequest" class="">
                        <div class="card card-body bg-dark text-white">
                            <div class="text-center h2 p-5 text-uppercase">
                                Booking Request
                            </div>
                        </div>
                    </a>
                </div>

                 <div class="col-12 col-md-6 mt-2">
                    <a href="/vehicles" class="">
                        <div class="card card-body bg-dark text-white">
                            <div class="text-center h2 p-5 text-uppercase">
                                Vehicles
                            </div>
                        </div>
                    </a>
                </div>

                 <div class="col-12 col-md-6 mt-2">
                    <a href="/customerinfo" class="">
                        <div class="card card-body bg-dark text-white">
                            <div class="text-center h2 p-5 text-uppercase">
                                Customer Info
                            </div>
                        </div>
                    </a>
                </div>

                 <div class="col-12 col-md-6 mt-2">
                    <a href="/driverinfo" class="">
                        <div class="card card-body bg-dark text-white">
                            <div class="text-center h2 p-5 text-uppercase">
                               Driver Info
                            </div>
                        </div>
                    </a>
                </div>

        </div>
    </div>



@endsection
