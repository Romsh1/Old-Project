<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Wahan</title>

    {{-- css --}}
    <link rel="stylesheet" href="{{ asset('/css/v1_app.css') }}">
    @yield('css')

</head>

<body>

    @include('sweetalert::alert')
    @yield('modal')


    {{-- main --}}
    <header class="navbar navbar-fixed-top  navbar-dark navbar-full bg-info doc-navbar-default">
        <button id="drawer_switcher" aria-controls="navdrawerDefault" aria-expanded="false"
            aria-label="Toggle Navdrawer" class="navbar-toggler" data-target="#navdrawerDefault"
            data-toggle="navdrawer"><span class="navbar-toggler-icon"></span></button>
        <span class="navbar-brand ">Wahan</span>
        <div class="ml-auto">
            <a href="/logout" class="ml-2">
                <i class="material-icons text-white">logout</i>
            </a>
        </div>

        <div>
        </div>
    </header>

    <div aria-hidden="true" class="navdrawer  " id="navdrawerDefault" tabindex="-1">
        <div class="navdrawer-content  bg-dark">

            <div class="mt-4">
                <img src="/images/logo.png" class="img-fluid d-block m-auto" style="height:80px;">
            </div>

            <nav class="navdrawer-nav text-uppercase">
                <a class="btn btn-warning nav-item nav-link text-left" href="/">
                    <i class="material-icons mr-3">dashboard</i>
                    Home
                </a>
                <a class="btn btn-warning nav-item nav-link text-left mt-2" href="/bookingrequest">
                    <i class="material-icons mr-3">group</i>
                    Booking Request
                </a>
                <a class="btn btn-warning nav-item nav-link text-left mt-2" href="/vehicles">
                    <i class="material-icons mr-3">group</i>
                   Vehicles
                </a>
                <a class="btn btn-warning nav-item nav-link text-left mt-2" href="/customerinfo">
                    <i class="material-icons mr-3">group</i>
                   Customer Info
                </a> 
                <a class="btn btn-warning nav-item nav-link text-left mt-2" href="/driverinfo">
                    <i class="material-icons mr-3">group</i>
                   Driver Info
                </a>
                <a class="btn btn-warning nav-item nav-link text-left mt-2" href="/logout">
                    <i class="material-icons mr-3">logout</i>
                   Logout
                </a>


            </nav>



        </div>
    </div>

    <div class="container-fluid mt-5 pt-3">

        @yield('content')
        <div class="my-4"></div>
    </div>

    {{-- !ENDS main --}}


    {{-- script --}}
    <script src="{{ asset('/js/v1_app.js') }}"></script>
    @yield('js')

</body>

</html>
