@extends('layout.base')
@section('content')



    {{-- add new member modal --}}
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal--fir">
        Add New Driver
    </button>

    {{-- list --}}
    <div class="card card-body mt-4 table-responsive">
        <div class="title font-weight-bold">
            Vehicle Lists
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @if (!empty($drivers))
                    @foreach ($drivers as $item)
                        <tr>

                            <td>
                                {{ $item->id }}
                            </td>
                            <td>
                                <img src="/images/driver/{{ $item->image }}" class="img-fluid" width="90px" alt="">
                            </td>
                            <td>
                                {{ $item->name }}
                            </td>
                            <td>
                                {{ $item->phone }}
                            </td>
                            <td>
                                {{ $item->email }}
                            </td>
                            <td>
                                {{ $item->address }}
                            </td>
                            <td>
                                <div class="d-flex">
                                    {{-- <a href="" class="btn btn-sm btn-dark mr-2" data-toggle="tooltip" title="View Trainer">
                                        <i class="material-icons">edit</i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                        data-target="#modal--sendnotice-{{ $item->id }}" data-toggle="tooltip"
                                        title="Send Notice ">
                                        <i class="material-icons">delete</i>
                                    </button> --}}

                                     <a  href="/driverinfo/delete/{{ $item->id }}"  class="btn btn-sm btn-danger mr-2" data-toggle="tooltip"  ">
                                        <i class="material-icons">delete</i>
                                    </a>

                                </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>

@endsection



@section('modal')
    {{-- model to add new --}}
    <div class="modal fade" id="modal--fir" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Driver</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/driverinfo/add" method="POST" enctype="multipart/form-data">
                        @csrf
                        {{-- <div class="form-group">
                        <label for="exampleInputEmail1">Image (optional)</label>
                        <input name="image" type="file" class="form-control">
                    </div> --}}
                        <div class="form-group">
                            <label for="exampleInputEmail1">Image *</label>
                            <input name="image" type="file" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Full Name *</label>
                            <input name="name" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">phone *</label>
                            <input name="phone" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">email *</label>
                            <input name="email" type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">address *</label>
                            <input name="address" type="text" class="form-control" required>
                        </div>
                        @if ($errors->any())
                            <div class="alert alert-danger error-container mt-2">
                                <div class="alert alert-danger">
                                    <ul class="errors">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif

                        <button type="submit" class="btn btn-success">Add</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


@endsection
