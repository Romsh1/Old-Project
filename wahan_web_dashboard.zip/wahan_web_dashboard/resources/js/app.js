var $ = require("jquery");
require("popper.js");
require("bootstrap");
require("daemonite-material");
require("slick-carousel");
require("magnific-popup");

$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
