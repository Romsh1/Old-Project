<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
*/

Route::get('/login', [AuthController::class, 'loginView'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout']);
Route::get('/register-admin', [AuthController::class, 'regiserAdmin']);


Route::middleware(['auth'])->group(
    function () {


        Route::get('/', [DashboardController::class, 'home']);
        Route::get('/bookingrequest', [DashboardController::class, 'bookingrequesthome']);
        Route::get('/bookingrequest/{booking_id}/{status}', [DashboardController::class, 'bookingConfirmStatusChange']);
        Route::post('/bookingrequest/{booking_id}/message', [DashboardController::class, 'bookingAddMessage']);
        // Route::get('/bookingrequest/delete/{id}', [DashboardController::class, 'bookingrequestdelete']);

        Route::get('/vehicles', [DashboardController::class, 'vehicleshome']);
        Route::post('/vehicles/add', [DashboardController::class, 'vehiclesadd']);
        Route::post('/vehicles/adddriver', [DashboardController::class, 'vehiclesadddriver']);
        Route::get('/customerinfo', [DashboardController::class, 'customerinfohome']);
        Route::get('/vehicles', [DashboardController::class, 'vehicleshome']);
        Route::post('/vehicles/update', [DashboardController::class, 'vehiclesupdate']);

        Route::get('/vehicles/delete/{id}', [DashboardController::class, 'vehiclesdelete']);

        Route::get('/driverinfo', [DashboardController::class, 'driverinfohome']);
        Route::get('/driverinfo/delete/{id}', [DashboardController::class, 'driverinfodelete']);

        Route::post('/driverinfo/add', [DashboardController::class, 'driverinfoadd']);


    }
);
