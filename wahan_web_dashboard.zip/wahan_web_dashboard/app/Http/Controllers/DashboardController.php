<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Driver;
use App\Models\Notification;
use App\Models\User;
use App\Models\Vehicle;
use App\Models\VehicleDetail;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function home()
    {
        return view('home');
    }
    public function bookingrequesthome()
    {

        $bookings = Booking::with('user', 'vehicle')->orderBy('created_at', 'desc')->get();

        // return $bookings;

        return view('bookingrequest.home', compact('bookings'));
    }
    public function bookingConfirmStatusChange($booking_id, $status)
    {


        $booking =   Booking::where('id', $booking_id)->first();
        if ($booking) {

            if ($status == "accept") {
                $booking->isBookingConfirmed = true;
            }
            if ($status == "decline") {
                $booking->isBookingConfirmed = false;
            }

            $booking->save();
        }


        return redirect('/bookingrequest');
    }
    public function bookingAddMessage($booking_id)
    {


        $booking =   Booking::where('id', $booking_id)->first();
        if ($booking) {

            $booking->message = request('notice');
            $booking->save();
        }


        return redirect('/bookingrequest');
    }
    public function bookingrequestdelete($id)
    {


        Booking::where('id', $id)->delete();



        return redirect('/bookingrequest');
    }
    public function vehiclesdelete($id)
    {


        VehicleDetail::where('id', $id)->delete();

        return redirect('/vehicles');
    }


    public function driverinfodelete($id)
    {
        Driver::where('id', $id)->delete();
        return redirect('/driverinfo');
    }
    public function vehicleshome()
    {
        $vehicles = VehicleDetail::with('driver')->get();
        // return $vehicles;
        $drivers = Driver::get();
        return view('vehicles.home', compact(
            'vehicles',
            'drivers'
        ));
    }
    public function vehiclesadd(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'color' => 'required',
            'seat' => 'required',
            'platenumber' => 'required',
            'fueltype' => 'required',
        ]);

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $unique_id = uniqid();
            $filename =  $unique_id . '_photo.' . $file->getClientOriginalExtension();
            $file->move('images/vehicles', $filename);


            VehicleDetail::create([
                'image' => $filename,
                'name' => $request->name,
                'color' => $request->color,
                'seat' => $request->seat,
                'platenumber' => $request->platenumber,
                'fueltype' => $request->fueltype,

            ]);
        }



        return redirect('/vehicles');
    }


    public function vehiclesupdate(Request $request)
    {
        $this->validate($request, [
            'id' => 'required',
            'name' => 'required',
            'color' => 'required',
            'seat' => 'required',
            'platenumber' => 'required',
            'fueltype' => 'required',
        ]);


        $vehicles =   VehicleDetail::find($request->id);
        if ($vehicles) {

            $vehicles->name =  $request->name;
            $vehicles->color =  $request->color;
            $vehicles->seat =  $request->seat;
            $vehicles->platenumber =  $request->platenumber;
            $vehicles->fueltype =  $request->fueltype;
            $vehicles->save();
        }

        return redirect('/vehicles');
    }
    public function vehiclesadddriver(Request $request)
    {
        $this->validate($request, [
            'id' => 'required',
            'driver_id' => 'required',
        ]);


        $vehicles =   VehicleDetail::find($request->id);
        if ($vehicles) {
            $vehicles->driver_id =  $request->driver_id;
            $vehicles->save();
        }

        return redirect('/vehicles');
    }

    public function customerinfohome()
    {

        $users = User::all();



        return view('customerinfo.home', compact('users'));
    }
    public function driverinfohome()
    {
        $drivers = Driver::get();
        return view('driverinfo.home', compact(
            'drivers'
        ));
    }
    public function driverinfoadd(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'address' => 'required',
        ]);

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $unique_id = uniqid();
            $filename =  $unique_id . '_photo.' . $file->getClientOriginalExtension();
            $file->move('images/driver', $filename);


            Driver::create([
                'image' => $filename,
                'name' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email,
                'address' => $request->address,
            ]);
        }



        return redirect('/driverinfo');
    }
}
