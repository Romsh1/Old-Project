<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Notification;
use App\Models\User;
use App\Models\VehicleDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApiController extends Controller
{
    public function registerUser(Request $request)
    {
        //validate
        $request->validate([
            'fullname' => 'required',
            'address' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'password' => 'required',
        ]);

        if (User::where('email', $request->email)->count() > 0) {
            $response = array(
                'status' => 404,
                'message' => 'email already exist.',
            );
            return response()->json($response);
        }


        $user =  User::create([
            'fullname' => $request->fullname,
            'phone' => $request->phone,
            'address' => $request->address,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'type' => 'customer',
            'gender' => 'no',


        ]);



        $response = array(
            'status' => 200,
            'message' => 'OK',
            'user' => $user,
            'email' => $user->email,
        );
        return response()->json($response);
    }
    public function loginuser(Request $request)
    {
        //validate
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        if (User::where('email', $request->email)->count() > 0) {

            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                $response = array(
                    'status' => 200,
                    'message' => 'OK',
                    'email' => $request->email,
                );
                return response()->json($response);
            }
        }

        $response = array(
            'status' => 404,
            'message' => 'OK',
        );
        return response()->json($response);
    }
    public function allvehicle()
    {

        $response = array(
            'status' => 200,
            'vehicles' => VehicleDetail::all(),
            'message' => 'OK',
        );

        return response()->json($response);
    }
    public function profileUser($email)
    {
        $user = User::whereEmail($email)->first();
        if ($user) {
            $user['status'] = 200;
            $user['message'] = 'OK';
            return response()->json($user);
        }
        $response = array(
            'status' => 404,
            'message' => 'OK',
        );

        return response()->json($response);
    }
    public function bookVehicle(Request $request)
    {

        $request->validate([
            'email' => 'required',
            'vehicle_id' => 'required',
            'from' => 'required',
            'to' => 'required',
            'noofpassengers' => 'required',
            'departure' => 'required',
            'return' => 'required',
        ]);

        $user =  User::whereEmail($request->email)->first();
        if ($user) {

            $vehicle = VehicleDetail::where('id', $request->vehicle_id)->first();
            if ($vehicle) {
                $booking = Booking::create([
                    'user_id' => $user->id,
                    'vehicle_id' => $vehicle->id,
                    'from' => $request->from,
                    'to' => $request->to,
                    'noofpassengers' => $request->noofpassengers,
                    'departure' => $request->departure,
                    'return' => $request->return,
                ]);


                $response = array(
                    'status' => 200,
                    'message' => 'OK',
                    'booking'=> $booking
                );

                return response()->json($response);
            } else {
                $response = array(
                    'status' => 404,
                    'message' => 'Vehicles Error',
                );

                return response()->json($response);
            }
        }else{
            $response = array(
                'status' => 404,
                'message' => 'Users Error',
            );

            return response()->json($response);
        }

        $response = array(
            'status' => 404,
            'message' => 'Server Error',
        );

        return response()->json($response);
    }
    public function updateProfile(Request $request)
    {

        $request->validate([
            'email' => 'required',
            'fullname' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);

        $user =  User::whereEmail($request->email)->first();
        if ($user) {


            $user->fullname = $request->fullname;
            $user->address = $request->address;
            $user->phone = $request->phone;
            $user->save();

            $response = array(
                'status' => 200,
                'message' => 'OK',
                'user' => $user
            );

            return response()->json($response);
        }else{
            $response = array(
                'status' => 404,
                'message' => 'Users Error',
            );

            return response()->json($response);
        }

        $response = array(
            'status' => 404,
            'message' => 'Server Error',
        );

        return response()->json($response);
    }
    public function userBookings($email)
    {

        $user = User::whereEmail($email)->first();
        if ($user) {

            $bookings = array();

            foreach (Booking::with('user', 'vehicle')->where('user_id', $user->id)->orderBy('created_at', 'desc')->get() as $booking ) {

                if($booking->isBookingConfirmed){
                    $isBookingConfirmed = "Accepted";
                }else{

                    $isBookingConfirmed = "On Hold";
                }

                array_push($bookings,array(
                    'id'=>$booking->id,
                    'image' => $booking->vehicle->image,
                    'vehiclename' => $booking->vehicle->name,
                    'color' => $booking->vehicle->color,
                    'seat' => $booking->vehicle->seat,
                    'platenumber' => $booking->vehicle->platenumber,
                    'fueltype' => $booking->vehicle->fueltype,
                    'from' => $booking->from,
                    'to' => $booking->to,
                    'departure' => $booking->departure,
                    'noofpassengers' => $booking->noofpassengers,
                    'return' => $booking->return,
                    'notice' => $booking->message,
                    'isBookingConfirmed' => $isBookingConfirmed,
                    'booked_at'=>$booking->created_at->toFormattedDateString(),
                ));
            }


            $response = array(
                'status' => 200,
                'message' => 'OK',
                'bookings' => $bookings
            );

            return response()->json($response);

        }
        $response = array(
            'status' => 404,
            'message' => 'OK',
        );


    }
}
