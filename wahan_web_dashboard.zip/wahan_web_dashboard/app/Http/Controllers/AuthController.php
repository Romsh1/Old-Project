<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function loginView()
    {
        return view('login');
    }
    public function regiserAdmin()
    {

        $email  = 'admin@admin.com';
        $password  = 'admin';
        if(User::whereEmail($email)->count() > 0)
        return "already exists";
                $user = User::create([
            'fullname' => 'no',
            'gender' => 'no',
            'phone' => 'no',
            'address' => 'no',
            'email' => $email,
            'password' => bcrypt($password),
            'type' => 'admin',
        ]);

        return $user;
    }
    public function login(Request $request)
    {

        $this->validate($request, [
            'email' => 'required',
            'password' => 'required'
        ]);

        // return $request;
        $credentials = [
            'email' => $request['email'],
            'password' => $request['password'],
        ];

        if (Auth::attempt($credentials)) {
            return redirect('/');
        } else {
            alert()->error('Invalid Credentials', 'Enter correct credentials.');
            return  back();
        }
    }
     public function logout(){
         Auth::logout();
         return redirect('/');
     }
}
