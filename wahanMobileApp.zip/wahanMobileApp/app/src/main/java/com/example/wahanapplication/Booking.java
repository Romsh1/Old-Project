package com.example.wahanapplication;

public class Booking {
    private  int id;
    private  String image;
    private  String vehiclename;
    private  String color;
    private  String seat;
    private  String platenumber;
    private  String fueltype;
    private  String from;
    private  String to;
    private  String departuredate;
    private  String noofpassengers;
    private  String returndate;
    private  String notice;
    private  String isBookingConfirmed;
    private  String booked_at;

    @Override
    public String toString() {
        return "Booking{" +
                "id=" + id +
                ", image='" + image + '\'' +
                ", vehiclename='" + vehiclename + '\'' +
                ", color='" + color + '\'' +
                ", seat='" + seat + '\'' +
                ", platenumber='" + platenumber + '\'' +
                ", fueltype='" + fueltype + '\'' +
                ", from='" + from + '\'' +
                ", to='" + to + '\'' +
                ", departuredate='" + departuredate + '\'' +
                ", noofpassengers='" + noofpassengers + '\'' +
                ", returndate='" + returndate + '\'' +
                ", notice='" + notice + '\'' +
                ", isBookingConfirmed='" + isBookingConfirmed + '\'' +
                ", booked_at='" + booked_at + '\'' +
                '}';
    }

    public Booking( ) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getVehiclename() {
        return vehiclename;
    }

    public void setVehiclename(String vehiclename) {
        this.vehiclename = vehiclename;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getPlatenumber() {
        return platenumber;
    }

    public void setPlatenumber(String platenumber) {
        this.platenumber = platenumber;
    }

    public String getFueltype() {
        return fueltype;
    }

    public void setFueltype(String fueltype) {
        this.fueltype = fueltype;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getDeparturedate() {
        return departuredate;
    }

    public void setDeparturedate(String departuredate) {
        this.departuredate = departuredate;
    }

    public String getNoofpassengers() {
        return noofpassengers;
    }

    public void setNoofpassengers(String noofpassengers) {
        this.noofpassengers = noofpassengers;
    }

    public String getReturndate() {
        return returndate;
    }

    public void setReturndate(String returndate) {
        this.returndate = returndate;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }

    public String getIsBookingConfirmed() {
        return isBookingConfirmed;
    }

    public void setIsBookingConfirmed(String isBookingConfirmed) {
        this.isBookingConfirmed = isBookingConfirmed;
    }

    public String getBooked_at() {
        return booked_at;
    }

    public void setBooked_at(String booked_at) {
        this.booked_at = booked_at;
    }
}
