package com.example.wahanapplication;

public class Vehicle {


    @Override
    public String toString() {
        return "Vehicle{" +
                "id=" + id +
                ", image='" + image + '\'' +
                ", name='" + name + '\'' +
                ", color='" + color + '\'' +
                ", seat='" + seat + '\'' +
                ", platenumber='" + platenumber + '\'' +
                ", fueltype='" + fueltype + '\'' +
                ", created_at='" + created_at + '\'' +
                ", updated_at='" + updated_at + '\'' +
                '}';
    }

    public Vehicle(int id, String image, String name, String color, String seat, String platenumber, String fueltype, String created_at, String updated_at) {
        this.id = id;
        this.image = image;
        this.name = name;
        this.color = color;
        this.seat = seat;
        this.platenumber = platenumber;
        this.fueltype = fueltype;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public Vehicle( ) {
    }

    private  int id;
    private  String image;
    private  String name;
    private  String color;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getPlatenumber() {
        return platenumber;
    }

    public void setPlatenumber(String platenumber) {
        this.platenumber = platenumber;
    }

    public String getFueltype() {
        return fueltype;
    }

    public void setFueltype(String fueltype) {
        this.fueltype = fueltype;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    private  String seat;
    private  String platenumber;
    private  String fueltype;
    private  String created_at;
    private  String updated_at;
}
