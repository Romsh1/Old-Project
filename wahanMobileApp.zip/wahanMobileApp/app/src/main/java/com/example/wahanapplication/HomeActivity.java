package com.example.wahanapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

//    ArrayAdapter<Vehicle> adapter;

    ArrayList<Vehicle> vehicles = new ArrayList<>();
    String email;

    Toolbar toolbar;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Wahan");




        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mRecyclerView.setHasFixedSize(true);
        mLayoutmanager = new LinearLayoutManager(this);
        mAdapter = new HomeVehicleAdapter(vehicles);

        mRecyclerView.setLayoutManager(mLayoutmanager);
        mRecyclerView.setAdapter(mAdapter);


    }


    @Override
    protected void onStart() {
        super.onStart();

        //fetch all vehicles
        fetchProfile();


    }

    private void fetchProfile() {

        //get email
        SharedPreferences sharedpreferences = getSharedPreferences("wahan", Context.MODE_PRIVATE);

        String useremail = sharedpreferences.getString("email", "");
        Log.d("Email", sharedpreferences.getString("email", ""));
        if (!useremail.equals("")) {

            RequestQueue queue = Volley.newRequestQueue(HomeActivity.this);
            //register user
            String url = getResources().getString(R.string.apidomain) + "/vehicles";


            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {

                            Log.d("Response", response.toString());


                            try {
                                JSONArray vehicle_data = (JSONArray) response.getJSONArray("vehicles");
                                for (int i = 0; i < vehicle_data.length(); i++) {

                                    JSONObject vehdata = (JSONObject) vehicle_data.get(i);
                                    Vehicle vehicle = new Vehicle();
                                    vehicle.setId(vehdata.getInt("id"));
                                    vehicle.setImage(vehdata.getString("image"));
                                    vehicle.setName(vehdata.getString("name"));
                                    vehicle.setColor(vehdata.getString("color"));
                                    vehicle.setSeat(vehdata.getString("seat"));
                                    vehicle.setPlatenumber(vehdata.getString("platenumber"));
                                    vehicle.setFueltype(vehdata.getString("fueltype"));
                                    vehicle.setCreated_at(vehdata.getString("created_at"));
                                    vehicle.setUpdated_at(vehdata.getString("updated_at"));
                                    vehicles.add(vehicle);
                                }
                                Log.d("Vehicle LIST", vehicles.toString());

                                    mAdapter.notifyDataSetChanged();
//                                adapter = new ArrayAdapter<Vehicle>(HomeActivity.this,
//                                        R.layout.activity_listview, vehicles);
//                                listView.setAdapter(adapter);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
//                            Toast.makeText(HomeActivity.this, "Error", Toast.LENGTH_SHORT).show();
                            Log.d("ERROR", error.getMessage());
                            VolleyLog.e("Error: ", error.getMessage());

                        }
                    });


            MySingleton.getInstance(HomeActivity.this).addToRequestQueue(jsonObjectRequest);


        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.profile) {
            //go to profile page
            Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
            startActivity(intent);
        }
        if (item.getItemId() == R.id.logout) {
            //clear login information for user
            SharedPreferences sharedpreferences = getSharedPreferences("wahan", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.clear();
            editor.commit();

            //go to profile page
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}