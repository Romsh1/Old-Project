package com.example.wahanapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {
    Toolbar toolbar;

    TextView fullname;
    TextView phone;
    TextView address;
    TextView email;
    TextView created_at;


    private String FULLNAME;
    private String PHONE;
    private String ADDRESS;
    private int once_mybookingbtn = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        fullname = (TextView) findViewById(R.id.nameTextView);
        phone = (TextView) findViewById(R.id.phoneTextView);
        address = (TextView) findViewById(R.id.addressTextView);
        email = (TextView) findViewById(R.id.emailTextView);
        created_at = (TextView) findViewById(R.id.registeredatTextView);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Profile");
        //enable back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to home screen
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });


        Button editprof = (Button) findViewById(R.id.editprofile);

        editprof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), ProfileEditActivity.class);
                intent.putExtra("FULLNAME", FULLNAME);
                intent.putExtra("PHONE", PHONE);
                intent.putExtra("ADDRESS", ADDRESS);

                startActivity(intent);
            }
        });

        Button mybookingbtn = (Button) findViewById(R.id.mybookings);

        mybookingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              once_mybookingbtn = once_mybookingbtn + 1;
              if (once_mybookingbtn <2 ){
                  Intent intent = new Intent(getApplicationContext(), MyBookingActivity.class);
                  startActivity(intent);
              }

            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();

        fetchProfile();
    }

    private void fetchProfile() {

        //get email
        SharedPreferences sharedpreferences = getSharedPreferences("wahan", Context.MODE_PRIVATE);

        String useremail = sharedpreferences.getString("email", "");
        Log.d("Email", sharedpreferences.getString("email", ""));
        if (!useremail.equals("")) {

            //  Instantiate the RequestQueue.
            RequestQueue queue = Volley.newRequestQueue(ProfileActivity.this);
            //register user
            String url = getResources().getString(R.string.apidomain) + "/profile/" + useremail;


            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {

                            Log.d("Response", response.toString());

                            try {

                                if (response.has("status") && response.get("status").toString().equals("200")) {

                                    fullname.setText("Name : " + response.get("fullname").toString());
                                    FULLNAME = response.get("fullname").toString();
                                    phone.setText("Phone : " + response.get("phone").toString());
                                    PHONE = response.get("phone").toString();
                                    address.setText("Address : " + response.get("address").toString());
                                    ADDRESS = response.get("address").toString();
                                    email.setText("Email : " + response.get("email").toString());
                                    created_at.setText("Registered At : " + response.get("created_at").toString());


                                } else {
                                    Toast.makeText(ProfileActivity.this, "Some error occured", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
//                            Toast.makeText(ProfileActivity.this, "Error", Toast.LENGTH_SHORT).show();
                            Log.d("ERROR", error.getMessage());
//                            VolleyLog.e("Error: ", error.getMessage());

                        }
                    });

            MySingleton.getInstance(ProfileActivity.this).addToRequestQueue(jsonObjectRequest);


        }
    }
}