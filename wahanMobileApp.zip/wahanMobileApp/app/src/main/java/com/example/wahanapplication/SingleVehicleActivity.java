package com.example.wahanapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

public class SingleVehicleActivity extends AppCompatActivity {


    Toolbar toolbar;

    String VEHICLE_ID;
    String VEHICLE_NAME;
    String VEHICLE_IMAGE;
    String VEHICLE_COLOR;
    String VEHICLE_SEAT;
    String VEHICLE_PLATENO;
    String VEHICLE_FUELTYPE;


    public TextView vehiclename;
    public TextView vehicleseat;
    public TextView vehiclecolor;
    public TextView vehiclefueltype;
    public ImageView vehicleimage;


    EditText from;
    EditText to;
    EditText noofpassengers;
    EditText departure;
    EditText returnedittext;
    Button bookvehicle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_vehicle);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //enable back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to home screen
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        VEHICLE_ID = getIntent().getStringExtra("VEHICLE_ID");
        VEHICLE_NAME = getIntent().getStringExtra("VEHICLE_NAME");
        getSupportActionBar().setTitle(VEHICLE_NAME);
        VEHICLE_IMAGE = getIntent().getStringExtra("VEHICLE_IMAGE");
        VEHICLE_COLOR = getIntent().getStringExtra("VEHICLE_COLOR");
        VEHICLE_SEAT = getIntent().getStringExtra("VEHICLE_SEAT");
        VEHICLE_PLATENO = getIntent().getStringExtra("VEHICLE_PLATENO");
        VEHICLE_FUELTYPE = getIntent().getStringExtra("VEHICLE_FUELTYPE");


        vehiclename = findViewById(R.id.vehiclename);
        vehicleseat = findViewById(R.id.vehicleseat);
        vehicleimage = findViewById(R.id.vehicleimage);
        vehiclecolor = findViewById(R.id.vehiclecolor);
        vehiclefueltype = findViewById(R.id.vehiclefueltype);

        from = (EditText) findViewById(R.id.from);
        to = (EditText) findViewById(R.id.to);
        noofpassengers = (EditText) findViewById(R.id.noofpassengers);
        bookvehicle = (Button) findViewById(R.id.bookvehicle);

        departure = (EditText) findViewById(R.id.departure);
        TextWatcher departuretw = new TextWatcher() {
            private String current = "";
            private String ddmmyyyy = "DDMMYYYY";
            private Calendar cal = Calendar.getInstance();

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(current)) {
                    String clean = s.toString().replaceAll("[^\\d.]|\\.", "");
                    String cleanC = current.replaceAll("[^\\d.]|\\.", "");

                    int cl = clean.length();
                    int sel = cl;
                    for (int i = 2; i <= cl && i < 6; i += 2) {
                        sel++;
                    }
                    //Fix for pressing delete next to a forward slash
                    if (clean.equals(cleanC)) sel--;

                    if (clean.length() < 8){
                        clean = clean + ddmmyyyy.substring(clean.length());
                    }else{
                        //This part makes sure that when we finish entering numbers
                        //the date is correct, fixing it otherwise
                        int day  = Integer.parseInt(clean.substring(0,2));
                        int mon  = Integer.parseInt(clean.substring(2,4));
                        int year = Integer.parseInt(clean.substring(4,8));

                        mon = mon < 1 ? 1 : mon > 12 ? 12 : mon;
                        cal.set(Calendar.MONTH, mon-1);
                        year = (year<1900)?1900:(year>2100)?2100:year;
                        cal.set(Calendar.YEAR, year);
                        // ^ first set year for the line below to work correctly
                        //with leap years - otherwise, date e.g. 29/02/2012
                        //would be automatically corrected to 28/02/2012

                        day = (day > cal.getActualMaximum(Calendar.DATE))? cal.getActualMaximum(Calendar.DATE):day;
                        clean = String.format("%02d%02d%02d",day, mon, year);
                    }
                    clean = String.format("%s/%s/%s", clean.substring(0, 2),
                            clean.substring(2, 4),
                            clean.substring(4, 8));

                    sel = sel < 0 ? 0 : sel;
                    current = clean;
                    departure.setText(current);
                    departure.setSelection(sel < current.length() ? sel : current.length());
                }
            }    @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}
        };
        departure.addTextChangedListener(departuretw);


        returnedittext = (EditText) findViewById(R.id.returnedit);
        TextWatcher returnedittexttw = new TextWatcher() {
            private String current = "";
            private String ddmmyyyy = "DDMMYYYY";
            private Calendar cal = Calendar.getInstance();

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(current)) {
                    String clean = s.toString().replaceAll("[^\\d.]|\\.", "");
                    String cleanC = current.replaceAll("[^\\d.]|\\.", "");

                    int cl = clean.length();
                    int sel = cl;
                    for (int i = 2; i <= cl && i < 6; i += 2) {
                        sel++;
                    }
                    //Fix for pressing delete next to a forward slash
                    if (clean.equals(cleanC)) sel--;

                    if (clean.length() < 8){
                        clean = clean + ddmmyyyy.substring(clean.length());
                    }else{
                        //This part makes sure that when we finish entering numbers
                        //the date is correct, fixing it otherwise
                        int day  = Integer.parseInt(clean.substring(0,2));
                        int mon  = Integer.parseInt(clean.substring(2,4));
                        int year = Integer.parseInt(clean.substring(4,8));

                        mon = mon < 1 ? 1 : mon > 12 ? 12 : mon;
                        cal.set(Calendar.MONTH, mon-1);
                        year = (year<1900)?1900:(year>2100)?2100:year;
                        cal.set(Calendar.YEAR, year);
                        // ^ first set year for the line below to work correctly
                        //with leap years - otherwise, date e.g. 29/02/2012
                        //would be automatically corrected to 28/02/2012

                        day = (day > cal.getActualMaximum(Calendar.DATE))? cal.getActualMaximum(Calendar.DATE):day;
                        clean = String.format("%02d%02d%02d",day, mon, year);
                    }
                    clean = String.format("%s/%s/%s", clean.substring(0, 2),
                            clean.substring(2, 4),
                            clean.substring(4, 8));

                    sel = sel < 0 ? 0 : sel;
                    current = clean;
                    returnedittext.setText(current);
                    returnedittext.setSelection(sel < current.length() ? sel : current.length());
                }
            }    @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(Editable s) {}
        };
        returnedittext.addTextChangedListener(returnedittexttw);


        vehiclename.setText(VEHICLE_NAME);
        Picasso.get().load(getResources().getString(R.string.vehicleimagedomain) + VEHICLE_IMAGE).into(vehicleimage);
        vehicleseat.setText("Seats : " + VEHICLE_SEAT);
        vehiclecolor.setText("Color : " + VEHICLE_COLOR);
        vehiclefueltype.setText("Fuel : " + VEHICLE_FUELTYPE);

        Log.d("vehicle_id", VEHICLE_ID);


        bookvehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookVehicle();
            }
        });

    }

    public void bookVehicle() {
        //check if valid inputs
        if (from.getText().toString().equals("") ||
                to.getText().toString().equals("") ||
                noofpassengers.getText().toString().equals("") ||
                departure.getText().toString().equals("") ||
                returnedittext.getText().toString().equals("")) {
            Toast.makeText(SingleVehicleActivity.this, "Empty Field !", Toast.LENGTH_SHORT).show();
            return;
        }

        //  Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(SingleVehicleActivity.this);
        //register user
        String url = getResources().getString(R.string.apidomain) + "/vehicle-book";

        SharedPreferences sharedpreferences = getSharedPreferences("wahan", Context.MODE_PRIVATE);

        // Post params to be sent to the server
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("email", sharedpreferences.getString("email", ""));

        params.put("vehicle_id", VEHICLE_ID);
        params.put("from", from.getText().toString());
        params.put("to", to.getText().toString());
        params.put("noofpassengers", noofpassengers.getText().toString());
        params.put("departure", departure.getText().toString());
        params.put("return", returnedittext.getText().toString());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, new JSONObject(params), new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        Log.d("RESPONSE", response.toString());
                        try {

                            if (response.has("status") && response.get("status").toString().equals("200")) {

                                Toast.makeText(SingleVehicleActivity.this, "Vehicle Booked Successfully", Toast.LENGTH_LONG).show();

                                //go to home screen
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                startActivity(intent);
                                finish();

                            } else {
                                Toast.makeText(SingleVehicleActivity.this, "Some error occured", Toast.LENGTH_SHORT).show();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SingleVehicleActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        Log.d("ERROR", error.getMessage());
                        VolleyLog.e("Error: ", error.getMessage());

                    }
                });

        MySingleton.getInstance(SingleVehicleActivity.this).addToRequestQueue(jsonObjectRequest);


    }



}