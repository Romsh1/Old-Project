package com.example.wahanapplication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class HomeVehicleAdapter extends RecyclerView.Adapter<HomeVehicleAdapter.HomeViewHolder> {
    private ArrayList<Vehicle> vehicles;
    public static class HomeViewHolder extends RecyclerView.ViewHolder{

        public TextView vehiclename;
        public TextView vehicleseat;
        public TextView vehiclecolor;
        public TextView vehiclefueltype;
        public ImageView vehicleimage;
        public HomeViewHolder(@NonNull View itemView) {
            super(itemView);
            vehiclename = itemView.findViewById(R.id.vehiclename);
            vehicleseat = itemView.findViewById(R.id.vehicleseat);
            vehicleimage = itemView.findViewById(R.id.vehicleimage);
            vehiclecolor = itemView.findViewById(R.id.vehiclecolor);
            vehiclefueltype = itemView.findViewById(R.id.vehiclefueltype);


        }
    }

    public  HomeVehicleAdapter(ArrayList<Vehicle> rVehicles){
  vehicles = rVehicles;
    }


    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_single_vehicle_item,parent,false);
        HomeViewHolder homeViewHolder = new HomeViewHolder(v);

        return  homeViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {

        Vehicle currentvehicle = vehicles.get(position);

        holder.vehiclename.setText(currentvehicle.getName());
        Picasso.get().load(holder.itemView.getContext().getResources().getString(R.string.vehicleimagedomain) + currentvehicle.getImage()).into(holder.vehicleimage);
        holder.vehicleseat.setText("Seats : "+currentvehicle.getSeat().toString());
        holder.vehiclecolor.setText("Color : "+currentvehicle.getColor().toString());
        holder.vehiclefueltype.setText("Fuel : "+currentvehicle.getFueltype().toString());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(holder.itemView.getContext(), SingleVehicleActivity.class);
                intent.putExtra("VEHICLE_ID", String.valueOf(currentvehicle.getId()));
                intent.putExtra("VEHICLE_NAME", currentvehicle.getName());
                intent.putExtra("VEHICLE_IMAGE", currentvehicle.getImage());
                intent.putExtra("VEHICLE_COLOR", currentvehicle.getColor());
                intent.putExtra("VEHICLE_SEAT", currentvehicle.getSeat());
                intent.putExtra("VEHICLE_PLATENO", currentvehicle.getPlatenumber());
                intent.putExtra("VEHICLE_FUELTYPE", currentvehicle.getFueltype());
                holder.itemView.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return vehicles.size();
    }


}
