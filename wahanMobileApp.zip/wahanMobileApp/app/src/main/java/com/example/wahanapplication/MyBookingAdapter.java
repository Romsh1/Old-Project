package com.example.wahanapplication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyBookingAdapter extends RecyclerView.Adapter<MyBookingAdapter.MyBookingViewHolder> {
    private ArrayList<Booking> bookins;

    public  MyBookingAdapter(ArrayList<Booking> rVehicles){
        bookins = rVehicles;
    }

    @NonNull
    @Override
    public MyBookingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.mybooking_single_vehicle_item,parent,false);
        MyBookingViewHolder homeViewHolder = new  MyBookingViewHolder(v);
        return  homeViewHolder;


    }
    public static class MyBookingViewHolder extends RecyclerView.ViewHolder{

        public TextView vehiclename;
        public TextView vehicleseat;
        public TextView vehiclecolor;
        public TextView vehiclefueltype;
        public ImageView vehicleimage;
        public TextView bookingstatus;

        public TextView fromview;
        public TextView toview;
        public TextView departuredate;
        public TextView noofpassengers;
        public TextView returndate;
        public TextView notice;

        public MyBookingViewHolder(@NonNull View itemView) {
            super(itemView);
            vehiclename = itemView.findViewById(R.id.vehiclename);
            vehicleseat = itemView.findViewById(R.id.vehicleseat);
            vehicleimage = itemView.findViewById(R.id.vehicleimage);
            vehiclecolor = itemView.findViewById(R.id.vehiclecolor);
            vehiclefueltype = itemView.findViewById(R.id.vehiclefueltype);
            bookingstatus = itemView.findViewById(R.id.status);
            fromview = itemView.findViewById(R.id.fromview);
            toview = itemView.findViewById(R.id.toview);
            departuredate = itemView.findViewById(R.id.departuredate);
            noofpassengers = itemView.findViewById(R.id.noofpassengers);
            returndate = itemView.findViewById(R.id.returndate);
            notice = itemView.findViewById(R.id.notice);



        }
    }
    @Override
    public void onBindViewHolder(@NonNull MyBookingViewHolder holder, int position) {
        Booking currentvehicle = bookins.get(position);

        holder.vehiclename.setText(currentvehicle.getVehiclename());
        Picasso.get().load(holder.itemView.getContext().getResources().getString(R.string.vehicleimagedomain) + currentvehicle.getImage()).into(holder.vehicleimage);
        holder.vehicleseat.setText("Seats : "+currentvehicle.getSeat().toString());
        holder.vehiclecolor.setText("Color : "+currentvehicle.getColor().toString());
        holder.vehiclefueltype.setText("Fuel : "+currentvehicle.getFueltype().toString());
        holder.bookingstatus.setText("Status : "+currentvehicle.getIsBookingConfirmed().toString());
        holder.fromview.setText("From : "+currentvehicle.getFrom().toString());
        holder.toview.setText("To : "+currentvehicle.getTo().toString());
        holder.noofpassengers.setText("NoOfPassenger : "+currentvehicle.getNoofpassengers().toString());
        holder.departuredate.setText("Departure : "+currentvehicle.getDeparturedate().toString());

        holder.returndate.setText("Return : "+currentvehicle.getReturndate().toString());

        if (!currentvehicle.getNotice().toString().equals("no")){
            holder.notice.setText("Notice : "+currentvehicle.getNotice().toString());
        }



    }

    @Override
    public int getItemCount() {
        return bookins.size();
    }



}
