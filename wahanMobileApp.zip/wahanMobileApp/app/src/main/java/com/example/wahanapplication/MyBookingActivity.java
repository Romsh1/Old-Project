package com.example.wahanapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MyBookingActivity extends AppCompatActivity {
    Toolbar toolbar;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutmanager;
    private TextView nobooking;
    ArrayList<Booking> bookings = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_booking);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Bookings");
        //enable back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to home screen
                Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        nobooking = (TextView)  findViewById(R.id.nobookingview);
        mRecyclerView.setHasFixedSize(true);
        mLayoutmanager = new LinearLayoutManager(this);
        mAdapter = new MyBookingAdapter(bookings);

        mRecyclerView.setLayoutManager(mLayoutmanager);
        mRecyclerView.setAdapter(mAdapter);


    }

    @Override
    protected void onStart() {
        super.onStart();

        //fetch all vehicles
        fetchData();


    }

    private void fetchData() {

        //get email
        SharedPreferences sharedpreferences = getSharedPreferences("wahan", Context.MODE_PRIVATE);

        String useremail = sharedpreferences.getString("email", "");
        Log.d("Email", sharedpreferences.getString("email", ""));
        if (!useremail.equals("")) {

            RequestQueue queue = Volley.newRequestQueue(MyBookingActivity.this);
            //register user
            String url = getResources().getString(R.string.apidomain) + "/booking/" + useremail;

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                    (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {

                            Log.d("Response", response.toString());


                            try {
                                JSONArray vehicle_data = (JSONArray) response.getJSONArray("bookings");
                                for (int i = 0; i < vehicle_data.length(); i++) {

                                    JSONObject vehdata = (JSONObject) vehicle_data.get(i);
                                    Booking vehicle = new Booking();
                                    vehicle.setId(vehdata.getInt("id"));
                                    vehicle.setImage(vehdata.getString("image"));
                                    vehicle.setVehiclename(vehdata.getString("vehiclename"));
                                    vehicle.setColor(vehdata.getString("color"));
                                    vehicle.setSeat(vehdata.getString("seat"));
                                    vehicle.setPlatenumber(vehdata.getString("platenumber"));
                                    vehicle.setFueltype(vehdata.getString("fueltype"));
                                    vehicle.setFrom(vehdata.getString("from"));
                                    vehicle.setTo(vehdata.getString("to"));
                                    vehicle.setDeparturedate(vehdata.getString("departure"));
                                    vehicle.setNoofpassengers(vehdata.getString("noofpassengers"));
                                    vehicle.setReturndate(vehdata.getString("return"));
                                    vehicle.setNotice(vehdata.getString("notice"));
                                    vehicle.setIsBookingConfirmed(vehdata.getString("isBookingConfirmed"));
                                    vehicle.setBooked_at(vehdata.getString("booked_at"));
                                    bookings.add(vehicle);
                                }
                                Log.d("Vehicle LIST", bookings.toString());

                                mAdapter.notifyDataSetChanged();

                                //change view for no data
                                if (bookings.size() > 0){
                                    nobooking.setVisibility(View.INVISIBLE);
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
//                            Toast.makeText(HomeActivity.this, "Error", Toast.LENGTH_SHORT).show();
                            Log.d("ERROR", error.getMessage());
                            VolleyLog.e("Error: ", error.getMessage());

                        }
                    });


            MySingleton.getInstance(MyBookingActivity.this).addToRequestQueue(jsonObjectRequest);


        }
    }


}